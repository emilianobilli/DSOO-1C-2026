f = open("archivito.txt", "at")
f.write("\nSaludos Emiliano")
f.close()